import React from 'react';
import ReactDOM from 'react-dom';
import AqiTable from './AqiTable';
import 'bootstrap/dist/css/bootstrap.css';


ReactDOM.render(
    <AqiTable />,
  document.getElementById('root')
);


